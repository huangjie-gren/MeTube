<template>
<div>
  <div class="photo-imager-container" style="display: none;">
   <div track-name="big_see" class="image-container" style="display: none;">
    <img src="//i0.hdslb.com/bfs/album/f05c635ad2a008049bc31b21c00266edbadec89a.png" alt="Image" title="" class="image-viewer" style="z-index: 0;" />
   </div> 
   <div class="loading-image-container" style="text-align: center;">
    <img src="//i0.hdslb.com/bfs/album/f05c635ad2a008049bc31b21c00266edbadec89a.png" class="image-viewer" />
   </div> 
   <div class="control-buttons">
    <!----> 
    <button class="control-button next"></button> 
    <button class="close-button"><i class="bp-icon-font icon-close"></i></button>
   </div> 
   <div class="image-hinter-ctnr">
    <div class="image-count-hinter">
     <div class="count-hinter">
      <span class="current-index">1</span> 
      <span>/ 5</span>
     </div> 
     <!---->
    </div>
   </div> 
   <!----> 
   <!----> 
   <div role="progress" class="loading-progress">
    <i class="loading-icon"></i>
   </div>
  </div>
</div>
</template>

<script>
/* eslint-disable */
import { mapGetters } from 'vuex'
import { showFollowers } from '@/api/friendManagement'
import { unfollow } from '@/api/friendManagement'

export default {
  computed: {
    ...mapGetters(['username'])
  },
  data() {
    return {
      input: ''
    }
  },
  created() {
    // showFollowers(this.$store.getters['username'])
    showFollowers(4)
      .then(response => {
        const { code } = response
        const { data } = response
        this.tableData = data   // 必须带this
      })
      .catch(error => {
        alert('created error')
      })
  },
  methods: {
  }
}
</script>

<style>
.photo-imager-container {
    z-index: 23333;
}
.photo-imager-container {
    width: 100%;
    height: 100%;
    position: fixed;
    background-color: #000;
    top: 0;
    left: 0;
    overflow: hidden;
    font-family: Arial, "Microsoft YaHei", "Microsoft Sans Serif", "Microsoft SanSerf", "微软雅黑";
}
</style>
