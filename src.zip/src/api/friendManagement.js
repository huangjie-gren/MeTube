import request from '@/utils/request'

const preUrl = 'http://localhost:8080'

export function ping() {
  return request({
    url: 'http://127.0.0.1:3000/api/v1/ping',
    method: 'get'
  })
}

export function hello() {
    return request({
      url: 'http://127.0.0.1:8080/hello',
      method: 'get'
    })
  }

  export function showFollowings(id) {
    return request({
      url: preUrl + '/showFollowings',
      method: 'get',
      params: { id }
    })
  }
  export function showFollowers(id) {
    return request({
      url: preUrl + '/showFollowers',
      method: 'get',
      params: { id }
    })
  }

  export function unfollow(from, to) {
    return request({
      url: preUrl + '/unfollow',
      method: 'get',
      params: { from, to }
    })
  }